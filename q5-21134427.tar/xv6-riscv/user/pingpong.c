#include "kernel/types.h"
#include "user/user.h"

// Aidan Darlington
// StudentID: 21134427
// Assignment 2 - Question 5
int
main(void)
{
    int p1[2];  // Pipe for parent-to-child communication
    int p2[2];  // Pipe for child-to-parent communication
    pipe(p1);   // Create the first pipe
    pipe(p2);   // Create the second pipe

    int pid = fork();  // Fork a child process

    if (pid == 0) {  // Child process
        int received_value;

        // Close the unused ends of the pipes
        close(p1[1]);
        close(p2[0]);

        // Read the integer from the parent via p1
        read(p1[0], &received_value, sizeof(received_value));

        // Print the child's PID and the received integer
        printf("%d Integer from parent = %d\n", getpid(), received_value);

        // Multiply the received integer by 4
        received_value *= 4;

        // Write the modified integer back to the parent via p2
        write(p2[1], &received_value, sizeof(received_value));

        // Close the pipe ends used by the child
        close(p1[0]);
        close(p2[1]);

        exit(0);

    } else {  // Parent process
        int send_value = 4;  // The integer to send
        int received_value;

        // Close the unused ends of the pipes
        close(p1[0]);
        close(p2[1]);

        // Write the integer to the child via p1
        write(p1[1], &send_value, sizeof(send_value));

        // Wait for the child to finish processing
        wait(0);

        // Read the modified integer from the child via p2
        read(p2[0], &received_value, sizeof(received_value));

        // Print the parent's PID and the modified integer
        printf("%d Integer from child = %d\n", getpid(), received_value);

        // Close the pipe ends used by the parent
        close(p1[1]);
        close(p2[0]);
    }
    exit(0);
}
